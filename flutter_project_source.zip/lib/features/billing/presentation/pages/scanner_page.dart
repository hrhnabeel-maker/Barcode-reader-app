import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:go_router/go_router.dart';
import 'package:vibration/vibration.dart';
import 'package:get_it/get_it.dart';

import '../../../product/domain/entities/product.dart';
import '../../../product/domain/usecases/product_usecases.dart';

class ScannerPage extends StatefulWidget {
  final bool selectMode;

  const ScannerPage({super.key, this.selectMode = false});

  @override
  State<ScannerPage> createState() => _ScannerPageState();
}

class _ScannerPageState extends State<ScannerPage> {
  final MobileScannerController controller = MobileScannerController(
    detectionSpeed: DetectionSpeed.noDuplicates,
    returnImage: false,
  );

  Product? _product;
  String? _barcode;
  bool _isLookingUp = false;
  bool _isScanned = false;
  bool _flashOn = false;

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  Future<void> _onDetect(BarcodeCapture capture) async {
    if (_isScanned) return;

    for (final barcode in capture.barcodes) {
      final rawValue = barcode.rawValue?.trim();
      if (rawValue == null || rawValue.isEmpty) continue;

      _isScanned = true;
      _barcode = rawValue;

      final hasVibrator = await Vibration.hasVibrator();
      if (hasVibrator == true) {
        await Vibration.vibrate(duration: 120);
      }

      if (!mounted) return;

      if (widget.selectMode) {
        context.pop(rawValue);
        return;
      }

      setState(() => _isLookingUp = true);
      await _lookupProduct(rawValue);
      break;
    }
  }

  Future<void> _lookupProduct(String barcode) async {
    final useCase = GetIt.I<GetProductByBarcodeUseCase>();
    final result = await useCase(barcode);

    if (!mounted) return;

    result.fold(
      (_) => setState(() {
        _product = null;
        _isLookingUp = false;
      }),
      (product) => setState(() {
        _product = product;
        _isLookingUp = false;
      }),
    );
  }

  Future<void> _manualLookup() async {
    final value = await showDialog<String>(
      context: context,
      builder: (context) {
        final controller = TextEditingController();
        return AlertDialog(
          title: const Text('Enter barcode'),
          content: TextField(
            controller: controller,
            autofocus: true,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              hintText: 'e.g. 6130000000000',
              prefixIcon: Icon(Icons.qr_code_2),
            ),
            onSubmitted: (value) => Navigator.pop(context, value.trim()),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, controller.text.trim()),
              child: const Text('Search'),
            ),
          ],
        );
      },
    );

    if (value == null || value.isEmpty || !mounted) return;

    setState(() {
      _barcode = value;
      _isScanned = true;
      _isLookingUp = true;
    });

    if (widget.selectMode) {
      context.pop(value);
      return;
    }

    await _lookupProduct(value);
  }

  void _scanAgain() {
    setState(() {
      _product = null;
      _barcode = null;
      _isLookingUp = false;
      _isScanned = false;
    });
    controller.start();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(
          widget.selectMode ? 'Scan Barcode' : 'Barcode Reader',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            tooltip: 'Manual barcode',
            onPressed: _manualLookup,
            icon: const Icon(Icons.keyboard),
          ),
          IconButton(
            tooltip: 'Flash',
            onPressed: () {
              setState(() => _flashOn = !_flashOn);
              controller.toggleTorch();
            },
            icon: Icon(_flashOn ? Icons.flash_on : Icons.flash_off),
          ),
        ],
      ),
      body: Stack(
        children: [
          MobileScanner(
            controller: controller,
            onDetect: _onDetect,
          ),
          Container(color: Colors.black.withValues(alpha: 0.10)),
          if (!_isScanned)
            Center(
              child: Container(
                width: 285,
                height: 170,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.white70, width: 2),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Stack(
                  children: [
                    _corner(Alignment.topLeft),
                    _corner(Alignment.topRight),
                    _corner(Alignment.bottomLeft),
                    _corner(Alignment.bottomRight),
                    Center(
                      child: Container(
                        height: 2,
                        margin: const EdgeInsets.symmetric(horizontal: 18),
                        color: Colors.redAccent,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          if (!_isScanned)
            const Positioned(
              left: 24,
              right: 24,
              bottom: 34,
              child: Text(
                'Place the product barcode inside the frame',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          if (_isScanned && !widget.selectMode) _buildResultCard(),
        ],
      ),
    );
  }

  Widget _buildResultCard() {
    final found = _product != null;

    return Positioned(
      left: 14,
      right: 14,
      bottom: 14,
      child: Card(
        elevation: 10,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 22,
                    backgroundColor:
                        (found ? Colors.green : Colors.orange).withValues(alpha: 0.12),
                    child: Icon(
                      found ? Icons.check_circle : Icons.help_outline,
                      color: found ? Colors.green : Colors.orange,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      _isLookingUp
                          ? 'Searching product…'
                          : found
                              ? 'Product found'
                              : 'Barcode scanned',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              _infoRow('Barcode', _barcode ?? '—', monospace: true),
              if (_isLookingUp)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 18),
                  child: LinearProgressIndicator(),
                )
              else if (found) ...[
                const Divider(height: 24),
                _infoRow('Product', _product!.name),
                _infoRow('Price', '${_product!.price.toStringAsFixed(2)}'),
                _infoRow('Stock', '${_product!.stock}'),
              ] else
                const Padding(
                  padding: EdgeInsets.only(top: 12),
                  child: Text(
                    'This barcode is not registered in the local product database.',
                    style: TextStyle(color: Colors.black54),
                  ),
                ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _scanAgain,
                  icon: const Icon(Icons.qr_code_scanner),
                  label: const Text('Scan another product'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _infoRow(String label, String value, {bool monospace = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 74,
            child: Text(
              label,
              style: const TextStyle(color: Colors.black54, fontSize: 13),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                fontWeight: FontWeight.w700,
                fontFamily: monospace ? 'monospace' : null,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _corner(Alignment alignment) {
    return Align(
      alignment: alignment,
      child: Container(
        width: 34,
        height: 34,
        decoration: BoxDecoration(
          border: Border(
            top: (alignment == Alignment.topLeft ||
                    alignment == Alignment.topRight)
                ? const BorderSide(color: Colors.greenAccent, width: 4)
                : BorderSide.none,
            bottom: (alignment == Alignment.bottomLeft ||
                    alignment == Alignment.bottomRight)
                ? const BorderSide(color: Colors.greenAccent, width: 4)
                : BorderSide.none,
            left: (alignment == Alignment.topLeft ||
                    alignment == Alignment.bottomLeft)
                ? const BorderSide(color: Colors.greenAccent, width: 4)
                : BorderSide.none,
            right: (alignment == Alignment.topRight ||
                    alignment == Alignment.bottomRight)
                ? const BorderSide(color: Colors.greenAccent, width: 4)
                : BorderSide.none,
          ),
        ),
      ),
    );
  }
}
